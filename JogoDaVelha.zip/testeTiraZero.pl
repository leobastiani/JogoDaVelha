teste :-
	get_single_char(T),
	writef("Teste: %w\n", [T]).